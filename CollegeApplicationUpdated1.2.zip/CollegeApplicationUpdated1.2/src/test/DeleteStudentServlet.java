package test;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteStudentServlet
 */
public class DeleteStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		int id = Integer.parseInt(request.getParameter("id"));
		StudentDAO sd = new StudentDAO();
		if(sd.deleteByIdenty(id)) {
			request.setAttribute("message", "Deleted Successfully");
			RequestDispatcher rd = request.getRequestDispatcher("studentManagement.jsp");
			rd.include(request, response);
		}
		else {
			request.setAttribute("message", " Not Deleted Successfully");
			RequestDispatcher rd = request.getRequestDispatcher("studentDisplay.jsp");
			rd.include(request, response);
		}
	}

}
