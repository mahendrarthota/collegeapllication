package test;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SearchStudentServlet
 */
public class SearchStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("email");
		StudentDAO sd = new StudentDAO();
		Student s1=sd.getByIdentity(email);
		request.setAttribute("condition", null);
		if(s1 != null ) {
			request.setAttribute("condition", "Found");
			request.setAttribute("studentObject", s1);
			RequestDispatcher rd = request.getRequestDispatcher("studentDisplay.jsp");
			rd.include(request, response);
			System.out.println(s1);
		}
			
		else {
			request.setAttribute("message", "student with this id Does Not exist");
			RequestDispatcher rd = request.getRequestDispatcher("studentDisplay.jsp");
			rd.include(request, response);
			System.out.println("student with this id Does Not exist");
			//request.setAttribute("message", "student with this id Does Not exist");
		}

	}

}
