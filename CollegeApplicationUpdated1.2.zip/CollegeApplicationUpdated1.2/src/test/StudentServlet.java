package test;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentServlet
 */
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		StudentDAO sd = new StudentDAO();		
//		Student s = new Student(1,"cs","123","1-10-2019","MCA",9876,"Bhimavaram",9876);

//		sd.insert(s);
//		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
//		out.println("1 row ichnserted");
//		
//		
//		Collection<Student> studentsData = sd.getAll();
//		for(Student ss : studentsData) {
//			System.out.println(ss);
//		}
//		
//		
		Student s1 =	sd.getByIdentity("cs@mail.com");
		if(s1 != null )
			System.out.println(s1);
		else
			System.out.println("student with this id Does Not exist");


	}

}
