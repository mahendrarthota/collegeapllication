package test;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class StudentDisplayAll
 */
public class StudentDisplayAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("in display all students");
		StudentDAO sd = new StudentDAO();
		System.out.println("dao object");
		Collection<Student> studentsData = sd.getAll();
		System.out.println("calliing dao method");
		System.out.println(studentsData);
//		for(Student ss: studentsData) {
//			System.out.println(ss);
//		}

		if (studentsData.isEmpty()) {
			request.setAttribute("message", "students Not Available");
			RequestDispatcher rd = request.getRequestDispatcher("studentManagement.jsp");
			rd.forward(request, response);

		}

		else {

			request.setAttribute("studentCollectionObject", studentsData);
			RequestDispatcher rd = request.getRequestDispatcher("studentDisplayAll.jsp");
			rd.forward(request, response);

			for (Student ss : studentsData) {
				System.out.println(ss);
			}

		}
	}

}
