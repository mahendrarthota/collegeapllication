package test;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NewStudentRegisterServlet
 */
public class NewStudentRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		StudentDAO sd = new StudentDAO();		
		String name = request.getParameter("name");
		String email =	request.getParameter("email");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String dateoFBirth = request.getParameter("dateofbirth");
		String branch = request.getParameter("branch");
		String dateOfJoin = request.getParameter("dateofjoin");
		String mobileNumber = request.getParameter("mobilenumber");
		String parentMobileNumber = request.getParameter("pmobilenumber");
		String address = request.getParameter("address");

		Student s = new Student();
		s.setName(name);
		s.setEmail(email);
		s.setPassword(password);
		s.setGender(gender);
		s.setDateoFBirth(dateoFBirth);
		s.setBranch(branch);
		s.setDateOfJoin(dateOfJoin);
		s.setMobilenumber(mobileNumber);
		s.setParentMobileNumber(parentMobileNumber);
		s.setAddress(address);
		sd.insert(s);
		request.setAttribute("message", "Registered Successfully"); // Will be available as ${message}
		RequestDispatcher rd = request.getRequestDispatcher("studentManagement.jsp");
		rd.include(request, response);
	}

}
