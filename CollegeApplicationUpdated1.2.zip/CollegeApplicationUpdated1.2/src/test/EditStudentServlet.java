package test;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class EditStudentServlet
 */
public class EditStudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("semail");
		String name = request.getParameter("editname");
		String mobilenumber = request.getParameter("editnumber");
		String parentnumber = request.getParameter("editparentnumber");
		StudentDAO sd = new StudentDAO();
		Student s1=sd.getByIdentity(email);
		if(s1 != null ) {
			s1.setName(name);
			s1.setMobilenumber(mobilenumber);
			s1.setParentMobileNumber(parentnumber);
			sd.update(s1);
			request.setAttribute("message", "student data updated successfully");
			RequestDispatcher rd = request.getRequestDispatcher("studentManagement.jsp");
			rd.include(request, response);
			System.out.println(s1);
		}
			
		else {
			request.setAttribute("message", "student data not updated successfully");
			RequestDispatcher rd = request.getRequestDispatcher("studentManagement.jsp");
			rd.include(request, response);
//			System.out.println("student with this id Does Not exist");
			//request.setAttribute("message", "student with this id Does Not exist");
		}
	}

}
