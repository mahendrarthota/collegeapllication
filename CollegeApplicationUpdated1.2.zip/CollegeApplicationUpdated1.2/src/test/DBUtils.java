package test;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBUtils {
	public static Connection buildConnection() throws Exception {
		String driverClassName = "oracle.jdbc.OracleDriver";
		String URL = "jdbc:oracle:thin:@localhost:1521:XE";
		String UID = "system";
		String PWD = "system";
		Class.forName(driverClassName);// Loading Driver
		Connection conn = DriverManager.getConnection(URL, UID, PWD);// Establish Connection
		return conn;
	}

}
