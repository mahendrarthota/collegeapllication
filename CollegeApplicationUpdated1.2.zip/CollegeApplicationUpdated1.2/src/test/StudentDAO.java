package test;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Locale;
public class StudentDAO {

	public void insert(Student s) {
		String sqlSequence = "select sequence_1.nextval from dual";
		String sqlQuery = "insert into student values(?,?,?,?,?,?,?,?,?,?,?)";
		try (Connection con = DBUtils.buildConnection();
				PreparedStatement pstmt = con.prepareStatement(sqlQuery);
				PreparedStatement pstmtSeq = con.prepareStatement(sqlSequence)
				) {
			ResultSet rs = pstmtSeq.executeQuery();
			 int myId=0;
			   if(rs.next())
			    myId = rs.getInt(1);
			int id = myId;
			String name = s.getName();
			String email = s.getEmail();
			String password = s.getPassword();
			String gender = s.getGender();
			String dateOfBirth = s.getDateoFBirth();
			String branch = s.getBranch();
			String dateOfJoin = s.getDateOfJoin();
			String mobileNumber = s.getMobilenumber();
			String parentMobileNumber = s.getParentMobileNumber();
			String address = s.getAddress();
			pstmt.setInt(1, id);
			pstmt.setString(2, name);
			pstmt.setString(3, email);
			pstmt.setString(4, password);
			pstmt.setString(5, gender);
			pstmt.setString(6, dateOfBirth);
			pstmt.setString(7, branch);
			pstmt.setString(8, dateOfJoin);
			pstmt.setString(9, mobileNumber);
			pstmt.setString(10, parentMobileNumber);
			pstmt.setString(11, address);
			int cout = pstmt.executeUpdate();
			System.out.println(cout + "record inserted");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public Collection<Student> getAll() {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from student";
		Collection<Student> students = new ArrayList<Student>();
		try (Connection con = DBUtils.buildConnection();
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuery)) {
			System.out.println("connection is ok and query executed");
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String email = rs.getString(3);
				String password = rs.getString(4);
				String gender = rs.getString(5);
				String dateoFBirth = rs.getString(6);
				String branch = rs.getString(7);
				String dateOfJoin = rs.getString(8);
				String mobileNumber = rs.getString(9);
				String parentMobileNumber = rs.getString(10);
				String address = rs.getString(11);

				Student s = new Student(id,name, email, password, gender, dateoFBirth, branch, dateOfJoin,
						mobileNumber, parentMobileNumber, address);
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);
				LocalDate jdate = LocalDate.parse(dateOfJoin, formatter);
				System.out.println(jdate);
				System.out.println(jdate.getYear()+"   "+jdate.getMonth()+"   "+jdate.getDayOfWeek());
				LocalDate today = LocalDate.now();
				Period age = Period.between(jdate, today);
				if(age.getYears()<=4)
					students.add(s);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return students;
	}

	public Student getByIdentity(String email) {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from student where email = ?";
		Student s = null;
		try (Connection con = DBUtils.buildConnection(); PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setString(1, email);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int sid = rs.getInt(1);
				String name = rs.getString(2);
				String semail = rs.getString(3);
				String password = rs.getString(4);
				String gender = rs.getString(5);
				String dateoFBirth = rs.getString(6);
				String branch = rs.getString(7);
				String dateOfJoin = rs.getString(8);
				String mobileNumber = rs.getString(9);
				String parentMobileNumber = rs.getString(10);
				String address = rs.getString(11);
				s = new Student(sid, name, semail, password, gender, dateoFBirth, branch, dateOfJoin, mobileNumber,
						parentMobileNumber, address);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return s;
	}

	public boolean deleteByIdenty(int id) {
		String sqlQuery = "delete from student where STUDENT_ID = ?";
		boolean flag=false;
		try (Connection con = DBUtils.buildConnection(); PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setInt(1, id);
			int count = pstmt.executeUpdate();
			System.out.println(count + "record deleted");
			if(count!=0) {
				flag=true;
			}
				
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flag;
	}

	public void update(Student s) {
		String sqlQuery = "update student set sname=?,mobileno=?,PARENTMOBILE_NUMBER=? where STUDENT_ID=?";
		try (Connection con = DBUtils.buildConnection(); PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			int id = s.getId();
			String name = s.getName();
			String mobilenumber = s.getMobilenumber();
			String pmobilenumber = s.getParentMobileNumber();
			pstmt.setString(1, name);
			pstmt.setString(2, mobilenumber);
			pstmt.setString(3, pmobilenumber);
			pstmt.setInt(4, id);
			int count = pstmt.executeUpdate();
			System.out.println(count + "record update");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	
	//Alumni display all
	public Collection<Student> getAlumniAll() {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from student";
		Collection<Student> students = new ArrayList<Student>();
		try (Connection con = DBUtils.buildConnection();
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuery)) {
			System.out.println("connection is ok and query executed");
			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				String email = rs.getString(3);
				String password = rs.getString(4);
				String gender = rs.getString(5);
				String dateoFBirth = rs.getString(6);
				String branch = rs.getString(7);
				String dateOfJoin = rs.getString(8);
				String mobileNumber = rs.getString(9);
				String parentMobileNumber = rs.getString(10);
				String address = rs.getString(11);

				Student s = new Student(id,name, email, password, gender, dateoFBirth, branch, dateOfJoin,
						mobileNumber, parentMobileNumber, address);
				
				DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);
				LocalDate jdate = LocalDate.parse(dateOfJoin, formatter);
				System.out.println(jdate);
				System.out.println(jdate.getYear()+"   "+jdate.getMonth()+"   "+jdate.getDayOfWeek());
				LocalDate today = LocalDate.now();
				Period age = Period.between(jdate, today);
				if(age.getYears()>4)
					students.add(s);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return students;
	}

}