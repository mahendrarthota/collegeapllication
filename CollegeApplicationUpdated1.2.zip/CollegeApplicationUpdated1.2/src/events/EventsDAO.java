package events;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import test.DBUtils;

public class EventsDAO {
	public void insert(Events e) {
		String sqlSequence = "select sequence_event.nextval from dual";
		String sqlQuery = "insert into events values(?,?,?,?)";
		try(Connection con = DBUtils.buildConnection();
				PreparedStatement pstmtSeq = con.prepareStatement(sqlSequence);
				PreparedStatement pstmt = con.prepareStatement(sqlQuery)){
			ResultSet rs = pstmtSeq.executeQuery();
			 int myId=0;
			   if(rs.next())
			    myId = rs.getInt(1);
			int id = myId;
			String ename = e.getEname();
			String date =e.getDate();
			String venue = e.getVenue();
			pstmt.setInt(1,  id);
			pstmt.setString(2,  ename);
			pstmt.setString(3, date);
			pstmt.setString(4, venue);
			
			int cout = pstmt.executeUpdate();
			System.out.println(cout+"record inserted");
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	public Collection<Events> getAll() {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from events";
		Collection<Events> events = new ArrayList<Events>();
		try(Connection con = DBUtils.buildConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery)	){
			
			while(rs.next()) {
				int id = rs.getInt(1);
				String ename = rs.getString(2);
				String date=rs.getString(3);
				String venue = rs.getString(4);
					Events e= new Events(id,ename,date,venue);
				events.add(e);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return events;
	}

		public boolean deleteByIdenty(int id) {
		boolean flag = false;
		String sqlQuery = "delete from events where eid = ?";
		try(Connection con = DBUtils.buildConnection();
				PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setInt(1, id);
			int count = pstmt.executeUpdate();
			System.out.println(count+"record deleted");
			if(count!=0) {
				flag=true;
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flag;
	}
}
