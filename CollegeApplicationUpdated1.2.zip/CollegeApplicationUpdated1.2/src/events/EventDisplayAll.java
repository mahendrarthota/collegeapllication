package events;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class EventDisplayAll
 */
public class EventDisplayAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// response.getWriter().append("Served at: ").append(request.getContextPath());

		System.out.println("in display all events");
		EventsDAO ed = new EventsDAO();
		System.out.println("dao object");
		Collection<Events> eventsData = ed.getAll();
		System.out.println("calliing dao method");
		System.out.println(eventsData);
		HttpSession  session=request.getSession();
		System.out.println(session.getAttribute("typeOfUser"));
		RequestDispatcher rd;
		if (eventsData.isEmpty()) {
			request.setAttribute("message", "events Not Available");
			if(session.getAttribute("typeOfUser").equals("admin")) {
				rd = request.getRequestDispatcher("eventManagement.jsp");
				rd.forward(request, response);
			}
			else if(session.getAttribute("typeOfUser").equals("student")) {
				rd = request.getRequestDispatcher("studentHome.jsp");
				rd.forward(request, response);
			}
			else if(session.getAttribute("typeOfUser").equals("faculty")) {
				rd = request.getRequestDispatcher("facultyHome.jsp");
				rd.forward(request, response);
			}
			else {
				rd = request.getRequestDispatcher("alumniHome.jsp");
				rd.forward(request, response);
			}
			
		} else {
			request.setAttribute("eventCollectionObject", eventsData);
			
			if(session.getAttribute("typeOfUser").equals("admin")) {
				rd = request.getRequestDispatcher("eventDisplayAll.jsp");
				rd.forward(request, response);
			}
			else if(session.getAttribute("typeOfUser").equals("student")) {
				rd = request.getRequestDispatcher("studentEvents.jsp");
				rd.forward(request, response);
			}
			else if(session.getAttribute("typeOfUser").equals("faculty")) {
				rd = request.getRequestDispatcher("facultyEvents.jsp");
				rd.forward(request, response);
			}
			else {
				rd = request.getRequestDispatcher("alumniEvents.jsp");
				rd.forward(request, response);
			}
			for (Events e : eventsData) {
				System.out.println(e);
			}

		}
	}

}
