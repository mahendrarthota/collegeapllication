package events;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class DeleteEventServlet
 */
public class DeleteEventServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		int eid = Integer.parseInt(request.getParameter("id"));
		EventsDAO ed = new EventsDAO();
		if(ed.deleteByIdenty(eid)) {
			request.setAttribute("message", "Event Deleted Successfully");
			RequestDispatcher rd = request.getRequestDispatcher("eventManagement.jsp");
			rd.include(request, response);
		}
		else {
			request.setAttribute("message", "Event Not Deleted Successfully");
			RequestDispatcher rd = request.getRequestDispatcher("eventManagement.jsp");
			rd.include(request, response);
		}

	}

}
