package events;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class NewEvent
 */
public class NewEvent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		EventsDAO ed = new EventsDAO();		
		String eventname = request.getParameter("eventname");
		String eventdate =	request.getParameter("eventdate");
		String venue = request.getParameter("venue");
		Events e = new Events();
		e.setEname(eventname);
		e.setDate(eventdate);
		e.setVenue(venue);
		ed.insert(e);
		request.setAttribute("message", "Event Registered Successfully"); // Will be available as ${message}
		RequestDispatcher rd = request.getRequestDispatcher("eventManagement.jsp");
		rd.include(request, response);
	}

}
