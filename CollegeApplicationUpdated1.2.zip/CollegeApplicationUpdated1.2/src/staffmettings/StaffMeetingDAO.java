package staffmettings;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import test.DBUtils;

public class StaffMeetingDAO {
	
	public void insert(StaffMeeting sm) {
		String sqlSequence = "select sequence_staffmeeting.nextval from dual";
		String sqlQuery = "insert into staffmeeting values(?,?,?,?,?)";
		try(Connection con = DBUtils.buildConnection();
				PreparedStatement pstmtSeq = con.prepareStatement(sqlSequence);
				PreparedStatement pstmt = con.prepareStatement(sqlQuery)){
			ResultSet rs = pstmtSeq.executeQuery();
			 int myId=0;
			   if(rs.next())
			    myId = rs.getInt(1);
			int id = myId;
			String mname = sm.getMeetingName(); 
			String date = sm.getDate();
			String time = sm.getTime();
			String venue = sm.getVenue();
			pstmt.setInt(1,  id);
			pstmt.setString(2,  mname);
			pstmt.setString(3, date);
			pstmt.setString(4, time);
			pstmt.setString(5, venue);
			
			int cout = pstmt.executeUpdate();
			System.out.println(cout+"record inserted");
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
		
	}
	public Collection<StaffMeeting> getAll() {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from staffmeeting";
		Collection<StaffMeeting> meetings = new ArrayList<StaffMeeting>();
		try(Connection con = DBUtils.buildConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery)	){
			
			while(rs.next()) {
				int id = rs.getInt(1);
				String smname = rs.getString(2);
				String date=rs.getString(3);
				String time = rs.getString(4);
				String venue = rs.getString(5);
				StaffMeeting e= new StaffMeeting(id,smname,date,time,venue);
				meetings.add(e);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return meetings;
	}

		public boolean deleteByIdenty(int id) {
		boolean flag = false;
		String sqlQuery = "delete from staffmeeting where id = ?";
		try(Connection con = DBUtils.buildConnection();
				PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setInt(1, id);
			int count = pstmt.executeUpdate();
			System.out.println(count+"record deleted");
			if(count!=0) {
				flag=true;
			}

		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flag;
	}
}
