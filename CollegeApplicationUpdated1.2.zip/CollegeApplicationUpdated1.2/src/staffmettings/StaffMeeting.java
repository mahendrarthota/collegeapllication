package staffmettings;

public class StaffMeeting {
	private int id;
	private String meetingName;
	private String date;
	private String time;
	private String venue;
	public StaffMeeting() {

	}
	public StaffMeeting(int id, String meetingName, String date, String time, String venue) {
		super();
		this.id = id;
		this.meetingName = meetingName;
		this.date = date;
		this.time = time;
		this.venue = venue;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMeetingName() {
		return meetingName;
	}
	public void setMeetingName(String meetingName) {
		this.meetingName = meetingName;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	public String getVenue() {
		return venue;
	}
	public void setVenue(String venue) {
		this.venue = venue;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((date == null) ? 0 : date.hashCode());
		result = prime * result + id;
		result = prime * result + ((meetingName == null) ? 0 : meetingName.hashCode());
		result = prime * result + ((time == null) ? 0 : time.hashCode());
		result = prime * result + ((venue == null) ? 0 : venue.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StaffMeeting other = (StaffMeeting) obj;
		if (date == null) {
			if (other.date != null)
				return false;
		} else if (!date.equals(other.date))
			return false;
		if (id != other.id)
			return false;
		if (meetingName == null) {
			if (other.meetingName != null)
				return false;
		} else if (!meetingName.equals(other.meetingName))
			return false;
		if (time == null) {
			if (other.time != null)
				return false;
		} else if (!time.equals(other.time))
			return false;
		if (venue == null) {
			if (other.venue != null)
				return false;
		} else if (!venue.equals(other.venue))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "StaffMeeting [id=" + id + ", meetingName=" + meetingName + ", date=" + date + ", time=" + time
				+ ", venue=" + venue + "]";
	}
	
	
}
