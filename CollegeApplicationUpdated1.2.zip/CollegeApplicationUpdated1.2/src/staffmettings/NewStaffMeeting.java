package staffmettings;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class NewStaffMeeting
 */
public class NewStaffMeeting extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		StaffMeetingDAO smd = new StaffMeetingDAO();		
		String meetingname = request.getParameter("meetingname");
		String meetingdate =	request.getParameter("meetingdate");
		String time = request.getParameter("time");
		String venue = request.getParameter("venue");
		StaffMeeting sm = new StaffMeeting();
		sm.setMeetingName(meetingname);
		sm.setDate(meetingdate);
		sm.setTime(time);
		sm.setVenue(venue);
		smd.insert(sm);
		request.setAttribute("message", "Meeting Registered Successfully"); // Will be available as ${message}
		RequestDispatcher rd = request.getRequestDispatcher("staffmeetingManagement.jsp");
		rd.include(request, response);
	}

}
