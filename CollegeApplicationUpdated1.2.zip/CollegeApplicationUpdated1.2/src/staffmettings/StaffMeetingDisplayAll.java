package staffmettings;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


/**
 * Servlet implementation class StaffMeetingDisplayAll
 */
public class StaffMeetingDisplayAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("in display all staffmeetings");
		StaffMeetingDAO smd = new StaffMeetingDAO();
		System.out.println("dao object");
		Collection<StaffMeeting> meetingsData = smd.getAll();
		System.out.println("calliing dao method");
		System.out.println(meetingsData);
		HttpSession  session=request.getSession();
		System.out.println(session.getAttribute("typeOfUser"));
		RequestDispatcher rd;
		if (meetingsData.isEmpty()) {
			request.setAttribute("message", "Staff Meetings Not Available");
			if(session.getAttribute("typeOfUser").equals("admin")) {
				rd = request.getRequestDispatcher("staffmeetingManagement.jsp");
				rd.forward(request, response);
			}
			
			else {
				rd = request.getRequestDispatcher("facultyHome.jsp");
				rd.forward(request, response);
			}
		} else {
			request.setAttribute("meetingCollectionObject", meetingsData);
			
			if(session.getAttribute("typeOfUser").equals("admin")) {
				rd = request.getRequestDispatcher("staffmeetingManagementDisplayAll.jsp");
				rd.forward(request, response);
			}
			else  {
				rd = request.getRequestDispatcher("facultyStaffMeetings.jsp");
				rd.forward(request, response);
			}
			for (StaffMeeting e : meetingsData) {
				System.out.println(e);
			}

		}

	}

}
