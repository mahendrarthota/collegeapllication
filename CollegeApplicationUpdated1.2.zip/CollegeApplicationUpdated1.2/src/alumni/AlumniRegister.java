package alumni;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class AlumniRegister
 */
public class AlumniRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		AlumniDAO ad = new AlumniDAO();
		Alumni f = ad.getByIdentity(email, password);
		if (f != null) {
			ad.insert(f);
			request.setAttribute("message","Congratulations! your Alumni Registration Process is Successfully Completed."); 
			RequestDispatcher rd = request.getRequestDispatcher("alumniRegister.jsp");
			rd.include(request, response);
		}
		else {
			request.setAttribute("message", "Sorry! you are not Eligible to register as Alumni"); 
			RequestDispatcher rd = request.getRequestDispatcher("alumniRegister.jsp");
			rd.include(request, response);

		}
	}

}
