package alumni;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.Student;
import test.StudentDAO;

/**
 * Servlet implementation class AlumniDisplayAll
 */
public class AlumniDisplayAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("in display all students");
		AlumniDAO ad = new AlumniDAO();
		System.out.println("dao object");
		Collection<Alumni> alumnisData = ad.getAll();
		System.out.println("calliing dao method");
		System.out.println(alumnisData);


		if (alumnisData.isEmpty()) {
			request.setAttribute("message", "alumni Not Available");
			RequestDispatcher rd = request.getRequestDispatcher("alumniHome.jsp");
			rd.forward(request, response);

		}

		else {

			request.setAttribute("alumniCollectionObject", alumnisData);
			RequestDispatcher rd = request.getRequestDispatcher("alumniDisplayAll.jsp");
			rd.forward(request, response);

			for (Alumni ss : alumnisData) {
				System.out.println(ss);
			}

		}

	}

}
