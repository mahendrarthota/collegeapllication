package alumni;

	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.Statement;
	import java.time.LocalDate;
	import java.time.Period;
	import java.time.format.DateTimeFormatter;
	import java.util.ArrayList;
	import java.util.Collection;
	import java.util.Locale;

import test.DBUtils;
	public class AlumniDAO {

		public void insert(Alumni a) {
			String sqlSequence = "select sequence_alumni.nextval from dual";
			String sqlQuery = "insert into Alumni values(?,?,?,?,?,?,?,?,?,?,?)";
			try (Connection con = DBUtils.buildConnection();
					PreparedStatement pstmt = con.prepareStatement(sqlQuery);
					PreparedStatement pstmtSeq = con.prepareStatement(sqlSequence)
					) {
				ResultSet rs = pstmtSeq.executeQuery();
				 int myId=0;
				   if(rs.next())
				    myId = rs.getInt(1);
				int id = myId;
				String name = a.getName();
				String email = a.getEmail();
				String password = a.getPassword();
				String gender = a.getGender();
				String dateOfBirth = a.getDateoFBirth();
				String branch = a.getBranch();
				String dateOfJoin = a.getDateOfJoin();
				String mobileNumber = a.getMobilenumber();
				String parentMobileNumber = a.getParentMobileNumber();
				String address = a.getAddress();
				pstmt.setInt(1, id);
				pstmt.setString(2, name);
				pstmt.setString(3, email);
				pstmt.setString(4, password);
				pstmt.setString(5, gender);
				pstmt.setString(6, dateOfBirth);
				pstmt.setString(7, branch);
				pstmt.setString(8, dateOfJoin);
				pstmt.setString(9, mobileNumber);
				pstmt.setString(10, parentMobileNumber);
				pstmt.setString(11, address);
				int cout = pstmt.executeUpdate();
				System.out.println(cout + "record inserted");
			} catch (Exception e) {
				e.printStackTrace();
			}

		}

		public Collection<Alumni> getAll() {
			// TODO Auto-generated method stub
			String sqlQuery = "select * from alumni ";
			Collection<Alumni> alumnis = new ArrayList<Alumni>();
			try (Connection con = DBUtils.buildConnection();
					Statement stmt = con.createStatement();
					ResultSet rs = stmt.executeQuery(sqlQuery)) {
				System.out.println("connection is ok and query executed");
				while (rs.next()) {
					int id = rs.getInt(1);
					String name = rs.getString(2);
					String email = rs.getString(3);
					String password = rs.getString(4);
					String gender = rs.getString(5);
					String dateoFBirth = rs.getString(6);
					String branch = rs.getString(7);
					String dateOfJoin = rs.getString(8);
					String mobileNumber = rs.getString(9);
					String parentMobileNumber = rs.getString(10);
					String address = rs.getString(11);

					Alumni a = new Alumni(id,name, email, password, gender, dateoFBirth, branch, dateOfJoin,
							mobileNumber, parentMobileNumber, address);
					
					alumnis.add(a);

				}

			} catch (Exception e) {
				e.printStackTrace();
			}
			
			return alumnis;
		}

		public Alumni getByIdentity(String email,String password) {
			// TODO Auto-generated method stub
			String sqlQuery = "select * from student where email = ? and password= ? ";
			String deleteSqlQuery = "delete from student where email = ? and password= ?";
			Alumni a = null;
			try (Connection con = DBUtils.buildConnection();
					PreparedStatement pstmt = con.prepareStatement(sqlQuery);
					PreparedStatement dpstmt = con.prepareStatement(deleteSqlQuery)
					) {
				pstmt.setString(1, email);
				pstmt.setString(2, password);
				dpstmt.setString(1, email);
				dpstmt.setString(2, password);
				ResultSet rs = pstmt.executeQuery();
				if (rs.next()) {
					int sid = rs.getInt(1);
					String name = rs.getString(2);
					String semail = rs.getString(3);
					String spassword = rs.getString(4);
					String gender = rs.getString(5);
					String dateoFBirth = rs.getString(6);
					String branch = rs.getString(7);
					String dateOfJoin = rs.getString(8);
					String mobileNumber = rs.getString(9);
					String parentMobileNumber = rs.getString(10);
					String address = rs.getString(11);
					
					DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.ENGLISH);
					LocalDate jdate = LocalDate.parse(dateOfJoin, formatter);
					System.out.println(jdate);
					System.out.println(jdate.getYear()+"   "+jdate.getMonth()+"   "+jdate.getDayOfWeek());
					LocalDate today = LocalDate.now();
					Period courseDuration= Period.between(jdate, today);
					if(courseDuration.getYears()>4)
					{
						int count = dpstmt.executeUpdate();
						System.out.println("deleted "+count);
						a = new Alumni(sid, name, semail, spassword, gender, dateoFBirth, branch, dateOfJoin, mobileNumber,
							parentMobileNumber, address);
					}

				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			return a;
		}

		

		
		
	
	}