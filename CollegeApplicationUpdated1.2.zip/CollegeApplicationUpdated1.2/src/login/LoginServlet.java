package login;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginServlet
 */
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String type = request.getParameter("type");
		LoginDAO ld = new LoginDAO();
		HttpSession  session=request.getSession();
		if (ld.validateLogin(email, password, type) == true) {
			if (type.equals("admin")) {
				session.setAttribute("typeOfUser",type);
				RequestDispatcher rd = request.getRequestDispatcher("adminHome.jsp");
				rd.forward(request, response);
				System.out.println("admin is valid");
			}
			else if (type.equals("student")) {
				session.setAttribute("typeOfUser",type);
				RequestDispatcher rd = request.getRequestDispatcher("studentHome.jsp");
				rd.forward(request, response);
				System.out.println("student is valid");
			}
			else if (type.equals("faculty")) {
				session.setAttribute("typeOfUser",type);
				RequestDispatcher rd = request.getRequestDispatcher("facultyHome.jsp");
				rd.forward(request, response);
				System.out.println("faculty is valid");
			}
			else {
				session.setAttribute("typeOfUser",type);
				RequestDispatcher rd = request.getRequestDispatcher("alumniHome.jsp");
				rd.forward(request, response);
				System.out.println("alumni is valid");
			}
		} 
		else {
			request.setAttribute("message", "Invalid Crendential"); // Will be available as ${message}
			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			rd.include(request, response);
			System.out.println("Invalid user name or password");
		}

	}

}
