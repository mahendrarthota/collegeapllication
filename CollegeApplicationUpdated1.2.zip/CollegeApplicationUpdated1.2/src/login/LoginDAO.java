package login;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import test.DBUtils;

public class LoginDAO {

	public boolean validateLogin(String email, String password, String type) {
		// TODO Auto-generated method stub
		boolean flag=false;
		String sqlQuery="";
		if(type.equals("student")) {
			sqlQuery = "select * from student where email = ? and password = ?";
		}
		else if(type.equals("faculty")) {
			sqlQuery = "select * from faculty where email = ? and password = ?";
		}
		else if(type.equals("admin")) {
			 sqlQuery = "select * from admin where admin_id = ? and password = ?";
		}
		else {
			 sqlQuery = "select * from alumni where email = ? and password = ?";
		}
		try(Connection con = DBUtils.buildConnection();
			PreparedStatement pstmt = con.prepareStatement(sqlQuery)){
			pstmt.setString(1, email);
			pstmt.setString(2, password);
			ResultSet rs= pstmt.executeQuery();
			if(rs.next()) {
				flag=true;
			}
			}
		catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
	}
//	public boolean facultyLogin(String email, String password) {
//		// TODO Auto-generated method stub
//		boolean flag=false;
//		String sqlQuery = "select * from faculty where email = ? and password = ?"; 
//		try(Connection con = DBUtils.buildConnection();
//			PreparedStatement pstmt = con.prepareStatement(sqlQuery)){
//			pstmt.setString(1, email);
//			pstmt.setString(2, password);
//			ResultSet rs= pstmt.executeQuery();
//			if(rs.next()) {
//				flag=true;
//			}
//			}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		return flag;
//	}
//	public boolean adminLogin(String email, String password) {
//		// TODO Auto-generated method stub
//		boolean flag=false;
//		String sqlQuery = "select * from admin where email = ? and password = ?"; 
//		try(Connection con = DBUtils.buildConnection();
//			PreparedStatement pstmt = con.prepareStatement(sqlQuery)){
//			pstmt.setString(1, email);
//			pstmt.setString(2, password);
//			ResultSet rs= pstmt.executeQuery();
//			if(rs.next()) {
//				flag=true;
//			}
//			}
//		catch(Exception e) {
//			e.printStackTrace();
//		}
//		return flag;
//	}
}