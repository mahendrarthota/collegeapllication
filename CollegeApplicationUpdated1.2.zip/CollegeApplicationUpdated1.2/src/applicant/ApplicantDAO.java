package applicant;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import test.DBUtils;

public class ApplicantDAO {

	public boolean insert(Applicant a) {
		boolean flag = false;
		String sqlQuery = "insert into applicant values(?,?,?,?,?,?,?)";
		try(Connection con = DBUtils.buildConnection();
				PreparedStatement pstmt = con.prepareStatement(sqlQuery)){
			String appli_name = a.getAppli_name();
			String email_id = a.getEmail_id();
			String gender = a.getGender();
			String branch =a.getBranch();
			String phone_num = a.getPhone_num();
			String status = a.getStatus();
			int percentage = a.getPercentage();
			
			pstmt.setString(1,  appli_name);
			pstmt.setString(2, email_id);
			pstmt.setString(3, gender);
			pstmt.setString(4, branch);
			pstmt.setString(5, phone_num);
			pstmt.setString(6, status);
			pstmt.setInt(7, percentage);
			
			int cout = pstmt.executeUpdate();
			if(cout!=0)
				flag=true;
			System.out.println(cout+"record inserted");
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return flag;
		
	}
	public Collection<Applicant> getAll() {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from applicant order by percentage desc";
		Collection<Applicant> applicants = new ArrayList<Applicant>();
		try(Connection con = DBUtils.buildConnection();
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sqlQuery)	){
			
			while(rs.next()) {
				String appli_name = rs.getString(1);
				String email_id = rs.getString(2);
				String gender= rs.getString(3);
				String branch =rs.getString(4);
				String phone_num = rs.getString(5);
				String status = rs.getString(6);
				int percentage = rs.getInt(7);
				Applicant a = new Applicant(appli_name,email_id,gender,branch,phone_num,status,percentage);
				applicants.add(a);
			}
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		return applicants;
	}

	public Applicant getByIdentity(String id) {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from applicant where email_id = ?"; 
		Applicant a =null;
		try(Connection con = DBUtils.buildConnection();
			PreparedStatement pstmt = con.prepareStatement(sqlQuery)){
			pstmt.setString(1, id);
			ResultSet rs= pstmt.executeQuery();
			if(rs.next()) {
				String appli_name = rs.getString(1);
				String email_id = rs.getString(2);
				String gender= rs.getString(3);
				String branch =rs.getString(4);
				String phone_num = rs.getString(5);
				String status = rs.getString(6);
				int percentage = rs.getInt(7);
			 a = new Applicant(appli_name,email_id,gender,branch,phone_num,status,percentage);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("in appDAO get data method "+a);
		return a;
	}


	
	public boolean deleteByIdenty(String email_id) {
		boolean flag = false;
		String sqlQuery = "delete from applicant where email_id = ?";
		try(Connection con = DBUtils.buildConnection();
				PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setString(1, email_id);
			int count = pstmt.executeUpdate();
			System.out.println(count+"record deleted");
			if(count!=0) {
				flag=true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flag;
	}


	public void update(Applicant a) {
		String sqlQuery = "update applicant set status=? where email_id=?";
		try(Connection con = DBUtils.buildConnection();
				PreparedStatement pstmt = con.prepareStatement(sqlQuery)){
			String email_id = a.getEmail_id();
			String status =a.getStatus();
			pstmt.setString(1, status);
			pstmt.setString(2, email_id);
			int count = pstmt.executeUpdate();
			System.out.println(count+"record update");
	}
		catch(Exception e) {
			e.printStackTrace();
		}

}


}