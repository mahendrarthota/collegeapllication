package applicant;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.Student;
import test.StudentDAO;

/**
 * Servlet implementation class ApplicantDisplayAll
 */
public class ApplicantDisplayAll extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	//	response.getWriter().append("Served at: ").append(request.getContextPath());
		System.out.println("in display all applicants");
		ApplicantDAO ad = new ApplicantDAO();
		System.out.println("dao object");
		Collection<Applicant> applicantsData = ad.getAll();
		System.out.println("calliing dao method");
		System.out.println(applicantsData);


		if (applicantsData.isEmpty()) {
			request.setAttribute("message", "applicants Not Available");
			RequestDispatcher rd = request.getRequestDispatcher("applicantManagement.jsp");
			rd.forward(request, response);
		}

		else {

			request.setAttribute("applicantCollectionObject", applicantsData);
			RequestDispatcher rd = request.getRequestDispatcher("applicantDisplayAll.jsp");
			rd.forward(request, response);

			for (Applicant aa : applicantsData) {
				System.out.println(aa);
			}

	}

	}
}
