package applicant;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.Student;
import test.StudentDAO;

/**
 * Servlet implementation class CheckServlet
 */
public class CheckStatusServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String email = request.getParameter("email");
		ApplicantDAO ad = new ApplicantDAO();
		Applicant a=ad.getByIdentity(email);
		request.setAttribute("condition", null);
		if(a != null ) {
			request.setAttribute("condition", "Found");
			request.setAttribute("applicantObject", a);
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.include(request, response);
			System.out.println(a);
		}
			
		else {
			request.setAttribute("message", "applicant with this id Does Not exist");
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.include(request, response);
			System.out.println("applicant with this id Does Not exist");
			//request.setAttribute("message", "student with this id Does Not exist");
		}

	}

}
