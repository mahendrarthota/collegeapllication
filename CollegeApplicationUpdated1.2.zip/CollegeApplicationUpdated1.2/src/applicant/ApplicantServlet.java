package applicant;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import applicant.Applicant;
import applicant.ApplicantDAO;

/**
 * Servlet implementation class ApplicantServlet
 */
public class ApplicantServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//			ApplicantDAO ad = new ApplicantDAO();		
//			Applicant a = new Applicant("karuna","CSE",1234567908,"3-413,navalur,chennai","karuna@gmail.com","female",9876);
//
//				ad.insert(a);
//				response.setContentType("text/html");
//				PrintWriter out = response.getWriter();
//				out.println("1 row inserted");
//				
//				
//				Collection<Applicant> applicantData = ad.getAll();
//				for(Applicant aa : applicantData) {
//					System.out.println(aa);
//					}	/*
				
//				Faculty f1 =	fd.getByIdentity("ECE004");
//				if(f1 != null )
//					System.out.println(f1);
//				else
//					System.out.println("Faculty with this id Does Not exist");
//		*/

	}

}
