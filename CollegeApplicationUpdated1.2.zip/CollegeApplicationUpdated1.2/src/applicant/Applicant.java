package applicant;

public class Applicant {
	private String appli_name;
	private String email_id;
	private String gender;
	private String branch;
	private String phone_num;
	private String status;
	private int percentage;
	
	public Applicant() {
		
	}

	public Applicant(String appli_name, String email_id, String gender, String branch, String phone_num, String status,
			int percentage) {
		super();
		this.appli_name = appli_name;
		this.email_id = email_id;
		this.gender = gender;
		this.branch = branch;
		this.phone_num = phone_num;
		this.status = status;
		this.percentage = percentage;
	}

	public String getAppli_name() {
		return appli_name;
	}

	public void setAppli_name(String appli_name) {
		this.appli_name = appli_name;
	}

	public String getEmail_id() {
		return email_id;
	}

	public void setEmail_id(String email_id) {
		this.email_id = email_id;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getPhone_num() {
		return phone_num;
	}

	public void setPhone_num(String phone_num) {
		this.phone_num = phone_num;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getPercentage() {
		return percentage;
	}

	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((appli_name == null) ? 0 : appli_name.hashCode());
		result = prime * result + ((branch == null) ? 0 : branch.hashCode());
		result = prime * result + ((email_id == null) ? 0 : email_id.hashCode());
		result = prime * result + ((gender == null) ? 0 : gender.hashCode());
		result = prime * result + percentage;
		result = prime * result + ((phone_num == null) ? 0 : phone_num.hashCode());
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Applicant other = (Applicant) obj;
		if (appli_name == null) {
			if (other.appli_name != null)
				return false;
		} else if (!appli_name.equals(other.appli_name))
			return false;
		if (branch == null) {
			if (other.branch != null)
				return false;
		} else if (!branch.equals(other.branch))
			return false;
		if (email_id == null) {
			if (other.email_id != null)
				return false;
		} else if (!email_id.equals(other.email_id))
			return false;
		if (gender == null) {
			if (other.gender != null)
				return false;
		} else if (!gender.equals(other.gender))
			return false;
		if (percentage != other.percentage)
			return false;
		if (phone_num == null) {
			if (other.phone_num != null)
				return false;
		} else if (!phone_num.equals(other.phone_num))
			return false;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Applicant [appli_name=" + appli_name + ", email_id=" + email_id + ", gender=" + gender + ", branch="
				+ branch + ", phone_num=" + phone_num + ", status=" + status + ", percentage=" + percentage + "]";
	}
		
	

}