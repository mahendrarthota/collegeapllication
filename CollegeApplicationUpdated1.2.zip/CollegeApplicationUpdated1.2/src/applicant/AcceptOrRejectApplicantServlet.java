package applicant;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import test.Student;
import test.StudentDAO;

/**
 * Servlet implementation class AcceptOrRejectApplicantServlet
 */
public class AcceptOrRejectApplicantServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String email = request.getParameter("id");
		String status = request.getParameter("status");
		ApplicantDAO ad = new ApplicantDAO();
		Applicant a=ad.getByIdentity(email);
		System.out.println("email "+email);
		System.out.println("status "+status);
		if(a != null ) {
			a.setStatus(status);
			ad.update(a);
			request.setAttribute("message", "applicant status updated successfully");
			RequestDispatcher rd = request.getRequestDispatcher("applicantManagement.jsp");
			rd.include(request, response);
			System.out.println(a);
		}
			
		else {
			request.setAttribute("message", "applicant status not updated successfully");
			RequestDispatcher rd = request.getRequestDispatcher("applicantManagement.jsp");
			rd.include(request, response);
//			System.out.println("student with this id Does Not exist");
			//request.setAttribute("message", "student with this id Does Not exist");
		}

	}

}
