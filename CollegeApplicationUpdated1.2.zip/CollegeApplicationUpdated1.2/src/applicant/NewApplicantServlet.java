package applicant;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class NewApplicantServlet
 */
public class NewApplicantServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String gender = request.getParameter("gender");
		String branch = request.getParameter("branch");
		String mobilenumber = request.getParameter("mobilenumber");
		String status = "pending";
		int percentage = Integer.parseInt(request.getParameter("percentage"));
		ApplicantDAO ad = new ApplicantDAO();		
		Applicant a = new Applicant(name, email, gender, branch, mobilenumber,status,percentage);
		if(ad.insert(a))
		{
			request.setAttribute("message", "Registered Successfully."); // Will be available as ${message}
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.include(request, response);
		}
		else {
			request.setAttribute("message", "Email already Registered."); // Will be available as ${message}
			RequestDispatcher rd = request.getRequestDispatcher("index.jsp");
			rd.include(request, response);
		}
		

	}

}
