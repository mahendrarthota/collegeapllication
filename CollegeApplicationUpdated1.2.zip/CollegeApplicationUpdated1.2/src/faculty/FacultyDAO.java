package faculty;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Collection;

import test.DBUtils;

public class FacultyDAO {

	public void insert(Faculty f) {
		String sqlSequence = "select sequence_faculty.nextval from dual";
		String sqlQuery = "insert into faculty values(?,?,?,?,?,?,?,?,?,?)";
		try (Connection con = DBUtils.buildConnection();
				PreparedStatement pstmt = con.prepareStatement(sqlQuery);
				PreparedStatement pstmtSeq = con.prepareStatement(sqlSequence)
				) {
			ResultSet rs = pstmtSeq.executeQuery();
			 int myId=0;
			   if(rs.next())
			    myId = rs.getInt(1);
			int id = myId;
			String fname = f.getFname();
			String email = f.getEmail();
			String password = f.getPassword();
			String gender = f.getGender();
			String dateOfBirth = f.getDateofbirth();
			String mobileNumber = f.getMobilenumber();
			String address = f.getAddress();
			String deptname = f.getDeptName();
			String doj = f.getDoj();
			
			
			pstmt.setInt(1, id);
			pstmt.setString(2, fname);
			pstmt.setString(3, email);
			pstmt.setString(4, password);
			pstmt.setString(5, gender);
			pstmt.setString(6, dateOfBirth);
			pstmt.setString(7, mobileNumber);
			pstmt.setString(8, address);
			pstmt.setString(9, deptname);
			pstmt.setString(10, doj);
			
			int cout = pstmt.executeUpdate();
			System.out.println(cout + "record inserted");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	public Collection<Faculty> getAll() {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from Faculty";
		Collection<Faculty> faculties = new ArrayList<Faculty>();
		try (Connection con = DBUtils.buildConnection();
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sqlQuery)) {
			System.out.println("connection is ok and query executed");
			while (rs.next()) {
				int id = rs.getInt(1);
				String fname = rs.getString(2);
				String email = rs.getString(3);
				String password = rs.getString(4);
				String gender = rs.getString(5);
				String dateOfBirth = rs.getString(6);
				String mobilenumber = rs.getString(7);
				String address = rs.getString(8);
				String deptname = rs.getString(9);
				String doj = rs.getString(10);
				

				Faculty f = new Faculty(id,fname, email, password, gender, dateOfBirth, mobilenumber, address,
						deptname, doj);
				faculties.add(f);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return faculties;
	}

	public Faculty getByIdentity(String email) {
		// TODO Auto-generated method stub
		String sqlQuery = "select * from faculty where email = ?";
		Faculty f = null;
		try (Connection con = DBUtils.buildConnection(); PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setString(1, email);
			ResultSet rs = pstmt.executeQuery();
			if (rs.next()) {
				int fid = rs.getInt(1);
				String fname = rs.getString(2);
				String femail = rs.getString(3);
				String password = rs.getString(4);
				String gender = rs.getString(5);
				String dateOfBirth = rs.getString(6);
				String mobilenumber = rs.getString(7);
				String address = rs.getString(8);
				String deptname = rs.getString(9);
				String doj = rs.getString(10);
				f = new Faculty(fid,fname, femail, password, gender, dateOfBirth, mobilenumber, address,
						deptname, doj);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	public boolean deleteByIdenty(int id) {
		String sqlQuery = "delete from Faculty where fid = ?";
		boolean flag=false;
		try (Connection con = DBUtils.buildConnection(); PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			pstmt.setInt(1, id);
			int count = pstmt.executeUpdate();
			System.out.println(count + "record deleted");
			if(count!=0) {
				flag=true;
			}
				
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return flag;
	}

	public void update(Faculty f) {
		String sqlQuery = "update faculty set fname=?,MOBILENUMBER=?,DEPTNAME=? where fid=?";
		try (Connection con = DBUtils.buildConnection(); PreparedStatement pstmt = con.prepareStatement(sqlQuery)) {
			int fid = f.getFid();
			String fname = f.getFname();
			String mobilenumber = f.getMobilenumber();
			String deptname = f.getDeptName();
			
			pstmt.setString(1, fname);
			pstmt.setString(2,mobilenumber);
			pstmt.setString(3, deptname);
			pstmt.setInt(4, fid);
			int count = pstmt.executeUpdate();
			System.out.println(count + "record update");
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
}