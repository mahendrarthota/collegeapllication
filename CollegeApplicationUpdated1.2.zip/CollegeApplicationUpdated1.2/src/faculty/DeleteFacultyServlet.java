package faculty;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class DeleteFacultyServlet
 */
public class DeleteFacultyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		
		
		int fid = Integer.parseInt(request.getParameter("id"));
		FacultyDAO fd = new FacultyDAO();
		if(fd.deleteByIdenty(fid)) {
			request.setAttribute("message", "Deleted Successfully");
			RequestDispatcher rd = request.getRequestDispatcher("facultyManagement.jsp");
			rd.include(request, response);
		}
		else {
			request.setAttribute("message", " Not Deleted Successfully");
			RequestDispatcher rd = request.getRequestDispatcher("facultyDisplay.jsp");
			rd.include(request, response);
		}
		
		
		
		
		
	}

	

}
