package faculty;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import faculty.Faculty;
import faculty.FacultyDAO;

/**
 * Servlet implementation class EditFacultyServlet
 */
public class EditFacultyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			String email = request.getParameter("email");
			String fname = request.getParameter("editname");
			String mobilenumber = request.getParameter("editnumber");
			String department = request.getParameter("editdepartment");
			System.out.println(email+" "+fname+" "+mobilenumber+" "+department);
			FacultyDAO fd = new FacultyDAO();
			Faculty f1=fd.getByIdentity(email);
			if(f1 != null ) {
				f1.setFname(fname);
				f1.setMobilenumber(mobilenumber);
				f1.setDeptName(department);
				fd.update(f1);
				request.setAttribute("message", "faculty data updated successfully");
				RequestDispatcher rd = request.getRequestDispatcher("facultyManagement.jsp");
				rd.include(request, response);
				System.out.println(f1);
			}
				
			else {
				request.setAttribute("message", "faculty data not updated successfully");
				RequestDispatcher rd = request.getRequestDispatcher("facultyManagement.jsp");
				rd.include(request, response);
//				System.out.println("student with this id Does Not exist");
				//request.setAttribute("message", "student with this id Does Not exist");
			}
	}

}
