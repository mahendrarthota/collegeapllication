package faculty;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Collection;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class FacultyServlet
 */
public class FacultyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		FacultyDAO fd = new FacultyDAO();		
//	Faculty f = new Faculty("ECE004","malla","malla@123",123456789,"navalur,chennai",4,"ECE","21-01-2012");
//
//		fd.insert(f);
//		response.setContentType("text/html");
//		PrintWriter out = response.getWriter();
//		out.println("1 row inserted");
//		
//		
//		Collection<Faculty> facultyData = fd.getAll();
//		for(Faculty ff : facultyData) {
//			System.out.println(ff);
//			}	/*
//		
//		Faculty f1 =	fd.getByIdentity("ECE004");
//		if(f1 != null )
//			System.out.println(f1);
//		else
//			System.out.println("Faculty with this id Does Not exist");


	}

	}

