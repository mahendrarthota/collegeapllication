package faculty;

import java.io.IOException;
import java.util.Collection;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class FacultyDisplayAll
 */
public class FacultyDisplayAll extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
	
		System.out.println("in display all faculties");
		FacultyDAO fd = new FacultyDAO();
		System.out.println("dao object");
		Collection<Faculty> facultiesData = fd.getAll();
		System.out.println("calliing dao method");
		System.out.println(facultiesData);

		if (facultiesData.isEmpty()) {
			request.setAttribute("message", "faculties Not Available");
			RequestDispatcher rd = request.getRequestDispatcher("facultyManagement.jsp");
			rd.forward(request, response);

		}

		else {

			request.setAttribute("facultyCollectionObject", facultiesData);
			RequestDispatcher rd = request.getRequestDispatcher("facultyDisplayAll.jsp");
			rd.forward(request, response);

			for (Faculty f1 : facultiesData) {
				System.out.println(f1);
			}

		}
	
	
	
	
		}


}
