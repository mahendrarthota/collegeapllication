package faculty;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class SearchFacultyServlet
 */
public class SearchFacultyServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
			
		// TODO Auto-generated method stub
				String email = request.getParameter("email");
				FacultyDAO fd = new FacultyDAO();
				Faculty f1=fd.getByIdentity(email);
				request.setAttribute("condition", null);
				if(f1 != null ) {
					request.setAttribute("condition", "Found");
					request.setAttribute("facultyObject", f1);
					RequestDispatcher rd = request.getRequestDispatcher("facultyDisplay.jsp");
					rd.include(request, response);
					System.out.println(f1);
				}
					
				else {
					request.setAttribute("message", "faculty with this id Does Not exist");
					RequestDispatcher rd = request.getRequestDispatcher("facultyDisplay.jsp");
					rd.include(request, response);
					System.out.println("faculty with this id Does Not exist");
					//request.setAttribute("message", "student with this id Does Not exist");
				}
		
		
	
//		doGet(request, response);
	}

}
