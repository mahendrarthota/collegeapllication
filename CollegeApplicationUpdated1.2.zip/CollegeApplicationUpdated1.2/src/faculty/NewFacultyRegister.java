package faculty;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class NewFacultyRegister
 */
public class NewFacultyRegister extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method students		
	
		FacultyDAO sd = new FacultyDAO();		
		String fname = request.getParameter("name");
		String email =	request.getParameter("email");
		String password = request.getParameter("password");
		String gender = request.getParameter("gender");
		String dateofbirth = request.getParameter("dateofbirth");
		String mobileNumber = request.getParameter("mobilenumber");
		String address = request.getParameter("address");
		String deptname = request.getParameter("dept");
		String doj = request.getParameter("dateofjoin");
				Faculty f = new Faculty();
		f.setFname(fname);
		f.setEmail(email);
		f.setPassword(password);
		f.setGender(gender);
		f.setDateofbirth(dateofbirth);
		f.setMobilenumber(mobileNumber);
		f.setAddress(address);
		f.setDeptName(deptname);
		f.setDoj(doj);
		
		sd.insert(f);
		request.setAttribute("message", "Registered Successfully"); // Will be available as ${message}
		RequestDispatcher rd = request.getRequestDispatcher("facultyManagement.jsp");
		rd.include(request, response);
		
		
		//doGet(request, response);
	}

}
